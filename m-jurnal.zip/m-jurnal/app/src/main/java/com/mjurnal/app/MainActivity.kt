package com.mjurnal.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var list: MutableList<Entry>
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var timeBtn: Button
    private val fmt = SimpleDateFormat("EEE, d MMM yyyy HH:mm", Locale("id", "ID"))
    private val dp get() = resources.displayMetrics.density

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Reminder.createChannel(this); Reminder.ensureWorker(this); Reminder.schedule(this)
        list = Store.load(this)
        val pad = (16 * dp).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply { text = "M-Jurnal"; textSize = 28f; setTypeface(typeface, Typeface.BOLD) })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val sw = Switch(this).apply { text = "Pengingat harian  "; isChecked = Store.enabled(this@MainActivity) }
        timeBtn = Button(this)
        showTime()
        timeBtn.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> Store.setTime(this, h, m); showTime(); Reminder.schedule(this) },
                Store.hour(this), Store.minute(this), true).show()
        }
        sw.setOnCheckedChangeListener { _, on ->
            Store.setEnabled(this, on); Reminder.schedule(this); if (on) askPermissions()
        }
        row.addView(sw); row.addView(timeBtn)
        root.addView(row)

        root.addView(Button(this).apply { text = "+ Tulis entri baru"; setOnClickListener { editDialog(null) } })
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        val lv = ListView(this).apply { adapter = this@MainActivity.adapter }
        lv.setOnItemClickListener { _, _, i, _ -> editDialog(sorted()[i]) }
        lv.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setMessage("Hapus entri ini?").setNegativeButton("Batal", null)
                .setPositiveButton("Hapus") { _, _ -> list.remove(sorted()[i]); Store.save(this, list); refresh() }.show()
            true
        }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); Reminder.schedule(this) } // ambil izin alarm yang baru diberikan

    private fun showTime() { timeBtn.text = "%02d:%02d".format(Store.hour(this), Store.minute(this)) }
    private fun sorted() = list.sortedByDescending { it.time }

    private fun refresh() {
        adapter.clear()
        adapter.addAll(sorted().map { "${it.title.ifBlank { "(tanpa judul)" }}\n${fmt.format(Date(it.time))}\n${it.body.take(80)}" })
    }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        else askExact()
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { askExact() }
    private fun askExact() {
        if (!Reminder.canExact(this)) {
            Toast.makeText(this, "Izinkan 'Alarm & pengingat' agar notifikasi tepat waktu", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
    }

    private fun editDialog(e: Entry?) {
        val t = EditText(this).apply { hint = "Judul"; setText(e?.title ?: "") }
        val c = EditText(this).apply {
            hint = "Isi jurnal hari ini..."; setText(e?.body ?: ""); minLines = 6; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; val p = (16 * dp).toInt(); setPadding(p, p, p, 0); addView(t); addView(c) }
        AlertDialog.Builder(this).setTitle(if (e == null) "Entri baru" else "Edit entri").setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                if (e == null) list.add(Entry(System.currentTimeMillis(), t.text.toString(), c.text.toString(), System.currentTimeMillis()))
                else { e.title = t.text.toString(); e.body = c.text.toString() }
                Store.save(this, list); refresh()
            }.show()
    }
}
