package com.mjurnal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val id: Long, var title: String, var body: String, var time: Long)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("mjurnal", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Entry> {
        val a = JSONArray(sp(c).getString("entries", "[]"))
        return MutableList(a.length()) { i -> a.getJSONObject(i).let {
            Entry(it.getLong("id"), it.getString("title"), it.getString("body"), it.getLong("time")) } }
    }
    fun save(c: Context, l: List<Entry>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("time", it.time)) }
        sp(c).edit().putString("entries", a.toString()).apply()
    }
    fun enabled(c: Context) = sp(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()
    fun hour(c: Context) = sp(c).getInt("h", 20)
    fun minute(c: Context) = sp(c).getInt("m", 0)
    fun setTime(c: Context, h: Int, m: Int) = sp(c).edit().putInt("h", h).putInt("m", m).apply()
}
