package com.mjurnal.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

object Reminder {
    private const val CH = "mjurnal_reminder"

    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26)
            c.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CH, "Pengingat jurnal", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun pending(c: Context) = PendingIntent.getBroadcast(
        c, 1, Intent(c, AlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun canExact(c: Context) = Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    /** Pasang alarm berikutnya (hari ini atau besok). Aman dipanggil berulang. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        if (!Store.enabled(c)) { am.cancel(pending(c)); return }
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Store.hour(c)); set(Calendar.MINUTE, Store.minute(c))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pending(c))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pending(c)) // fallback: kurang presisi
    }

    /** WorkManager berkala: memulihkan alarm jika sistem menghapusnya. */
    fun ensureWorker(c: Context) = WorkManager.getInstance(c).enqueueUniquePeriodicWork(
        "heal", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<HealWorker>(6, TimeUnit.HOURS).build())

    fun show(c: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH).setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Waktunya menulis jurnal").setContentText("Bagaimana harimu? Catat sekarang di M-Jurnal.")
            .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        NotificationManagerCompat.from(c).notify(1, n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Reminder.createChannel(c); Reminder.show(c); Reminder.schedule(c) }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Reminder.createChannel(c); Reminder.ensureWorker(c); Reminder.schedule(c) }
}

class HealWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { Reminder.schedule(applicationContext); return Result.success() }
}
