# M-Jurnal
Buka folder ini di Android Studio (Koala atau lebih baru, JDK 17), tunggu Gradle sync, lalu Build > Build APK(s).
Notifikasi: AlarmManager (setExactAndAllowWhileIdle) + BootReceiver + WorkManager berkala sebagai pemulih jadwal.
